# AI-PROPHET-BACKEND

### 运行步骤
```shell
pip install -r requirements.txt
python manage.py runserver
```

### 数据库迁移部署
```shell
python manage.py makemigrations
python manage.py migrate
```

### 创建超级用户
```shell
python manage.py createsuperuser
```
