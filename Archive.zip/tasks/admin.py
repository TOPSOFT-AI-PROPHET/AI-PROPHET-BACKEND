from django.contrib import admin
from .models import Task, AIModel

admin.site.register(AIModel)
admin.site.register(Task)